import React from 'react';
import {Route, Switch} from 'react-router-dom';
import SideBar from "../components/layout/SideBar";
import SystemForceChartContainer from "../containers/SystemForceChartContainer";
import QpsChartChartContainer from "../containers/QpsChartContainer";
import SystemSetting from "../containers/SystemSetting";
import AppInfoSetting from "../containers/AppInfoSetting";
import WarningContainer from "../containers/WarningContainer";
import WarningRuleInfo from "../containers/WarningRuleInfo";
import Home from "../containers/Home";


export const SiderMenusRoute = () =>
    <Route path="*" component={SideBar}/>;

export const ContentRoute=()=>
    <Switch>
        {/*<Route exact path={'/'} component={Home}/>*/}
        <Route exact path={'/'} component={SystemForceChartContainer}/>
        <Route exact path={'/SystemForceChartContainer'} component={SystemForceChartContainer}/>
        <Route exact path={'/QpsChartChartContainer'} component={QpsChartChartContainer}/>
        <Route exact path={'/SystemSetting'} component={SystemSetting}/>
        <Route exact path={'/AppInfoSetting'} component={AppInfoSetting}/>
        <Route exact path={'/WarningContainer'} component={WarningContainer}/>
        <Route exact path={'/WarningRuleInfo'} component={WarningRuleInfo}/>
    </Switch>
;




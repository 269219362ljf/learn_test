import {combineReducers} from 'redux';
import {SystemForceDataReducer} from "../containers/SystemForceChartContainer";

//在初始化时会进行两次测试，第一次会发送初始化的action，第二次会发送一个未知的action，确保reducer返回值不为undefined
const reducers=combineReducers({
    sysForceData:SystemForceDataReducer
});

export default reducers;


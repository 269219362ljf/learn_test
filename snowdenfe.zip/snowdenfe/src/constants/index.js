export const componentUrlNameMap={
    'home':'首页',
    'SystemForceChartContainer':'简单力导图',
    'QpsChartChartContainer':'风控系统qps',
    'SystemSetting':'系统变量设置',
    'AppInfoSetting':'风控系统监控appid',
    'WarningContainer':'风控系统监控手动告警',
    'WarningRuleInfo':'报警规则配置'
};

export const snowden_api_url=window.location.origin.substr(0,window.location.origin.lastIndexOf(":")+1)+"8083";








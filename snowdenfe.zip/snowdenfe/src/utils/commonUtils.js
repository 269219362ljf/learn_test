
export function transformNodesAndLines(data) {
    const result={};
    let nodes = [];
    let nodeIndex=[];
    for (let i = 0; i < data.nodes.length; i++) {
        nodes[i] = {};
        nodes[i].name = data.nodes[i].node_name;
        nodes[i].type=data.nodes[i].node_type;
        nodeIndex[i]=nodes[i].name;
    }
    result.nodes = nodes;
    let edges = [];
    for (let i = 0; i < data.lines.length; i++) {
        edges[i] = {};
        edges[i].source = nodeIndex.indexOf(data.lines[i].source);
        edges[i].target = nodeIndex.indexOf(data.lines[i].target);
        edges[i].value = 10;
        edges[i].counter=data.lines[i].counter;
        edges[i].responseTime=data.lines[i].responseTime;
    }
    result.edges = edges;
    return result;
}

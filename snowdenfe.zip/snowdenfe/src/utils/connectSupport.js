import axios from "axios";

export function urlGet(url,values,success,err){
    let config={
        headers: {
            'Accept': 'application/json',
            'content-type':'application/json'
        }
    };
    if(values!==undefined&&values!==null){
        config.params=values;
    }
    axios.get(url,config).then((response)=>{
        success(response);
    }).catch((error)=>{
        err(error);
    });
}

export function urlpost(url,values,success,err) {
    axios.post(url,values)
        .then((response)=>{
            success(response);
        }).catch((error)=>{
        err(error);
    });
}

export function urlput(url,values,success,err) {
    axios.put(url,values)
        .then((response)=>{
            success(response);
        }).catch((error)=>{
        err(error);
    });
}

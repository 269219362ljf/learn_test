import React from 'react'
import PropTypes from 'prop-types'
import { Menu } from 'antd';
import { Link } from 'react-router-dom';



const { SubMenu } = Menu;

const SideBar = ({match}) => (
    <div style={{paddingBottom:'120px'}}>
        <Menu theme="dark" defaultSelectedKeys={[match.url]} selectedKeys={[match.url]} defaultOpenKeys={['sub4']} mode="inline">
            {/*<Menu.Item key="/">*/}
                {/*<Link to="/">*/}
                    {/*<span className="iconfont icon-shouye">首页</span>*/}
                {/*</Link>*/}
            {/*</Menu.Item>*/}
            <SubMenu
                key="sub1"
                title={<span className="iconfont icon-tongji">图表</span>}
            >
                <Menu.Item key="/"><Link to="/">风控系统拓扑图</Link></Menu.Item>
            </SubMenu>
            {/*<SubMenu*/}
                {/*key="sub2"*/}
                {/*title={<span className="iconfont icon-jilu">数据</span>}>*/}
                {/*<Menu.Item key={"/QpsChartChartContainer"}><Link to="/QpsChartChartContainer">Qps数据表</Link></Menu.Item>*/}
            {/*</SubMenu>*/}
            <SubMenu
                key="sub3"
                title={<span className="iconfont icon-diannao">系统设置</span>}>
                <Menu.Item key={"/SystemSetting"}><Link to="/SystemSetting">系统变量设置</Link></Menu.Item>
                <Menu.Item key={"/AppInfoSetting"}><Link to="/AppInfoSetting">风控系统监控appid</Link></Menu.Item>
            </SubMenu>
            <SubMenu
                key="sub4"
                title={<span className="iconfont icon-yujing">告警</span>}>
                <Menu.Item key={"/WarningContainer"}><Link to="/WarningContainer">手动告警</Link></Menu.Item>
                <Menu.Item key={"/WarningRuleInfo"}><Link to="/WarningRuleInfo">告警规则配置</Link></Menu.Item>
            </SubMenu>
        </Menu>
    </div>
);

SideBar.propTypes = {
    match: PropTypes.object.isRequired
};

export default SideBar;

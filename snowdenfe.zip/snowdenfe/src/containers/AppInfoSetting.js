import React from 'react';
import {Card,Button, Col, Form, Input, Row,Table} from 'antd';
import axios from 'axios';
import {snowden_api_url} from '../constants';
const FormItem = Form.Item;

//查询表单
class AppFormClass extends React.Component{
    render(){
        const  {getFieldDecorator} = this.props.form;
        return (
            <Form className="ant-advanced-search-form"
                  onSubmit={this.appDataSubmit}
                  layout="inline"
            >
                <Row>
                    <Col span={8}  >
                        <FormItem label={`AppId`} >
                            {getFieldDecorator('appid', {
                                rules: [{
                                    required: false
                                }],
                            })(
                                <Input placeholder="新增appid"  />
                            )}
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span={24} style={{textAlign:"right"}}>
                        <Button type="primary" htmlType="submit">提交</Button>
                        <Button style={{ marginLeft: 8 }} onClick={this.formReset}>
                            清空
                        </Button>
                    </Col>
                </Row>
            </Form>
        );
    }
    appDataSubmit=(e)=>{
        this.props.form.validateFields((err, values) => {
            newAppIdSubmit(values,this.props.parent.updateData);
        });
    };
    //重置function
    formReset = () => {
        this.props.form.resetFields();
    };

}

const AppForm = Form.create()(AppFormClass);

//数据表
class AppDataTable extends React.Component{
    render(){
        return(
            <Table columns={this.columns} dataSource={this.props.data} />
        );
    }

    columns=[{
        title:'appId',
        dataIndex:'appId',
        align:'center',
        defaultSortOrder:'descend',
        sorter: (a,b)=>columnSorter(a.appId,b.appId),
    }];
}

//整个页面
class AppInfoSetting extends React.Component{
    render(){
        return (
            <div className={"gutter-example simple-force-chart-demo"}>
                <Row gutter={10}>
                    <Col className={"gutter-row"} md={24}>
                        <div className={"gutter-box"}>
                            <Card title={"风控系统监控appid"} bordered={false}>
                                <AppForm parent={this}/>
                                <AppDataTable data={this.appdata} />
                            </Card>
                        </div>
                    </Col>
                </Row>
            </div>
        );
    }

    componentDidMount() {
        this.appdata=queryAppData(this.updateData);
    }

    updateData=(data)=>{
        //由于修改的不是state，所以默认不会重新渲染，需要强制重新渲染
        this.appdata=data.data;
        this.forceUpdate();
    };

}

export default AppInfoSetting;

function send_request(url,params,updatefunction) {
    try {
        let config={
            headers: {
                'Accept': 'application/json',
                'content-type': 'application/json'
            },
        };
        if(params!==undefined&&params!==null){
            config.params=params;
        }
        axios.get(snowden_api_url + url, config)
            .then((response) => {
                if (typeof updatefunction === "function") {
                    updatefunction(response.data);
                }
            }).catch((error) => {
                alert("error");
            console.error("error", error);
        });
    } catch (err) {
        console.error(err);
    }
}

//获取APP数据
function queryAppData(updatefunction){
    send_request('/queryData/queryApp',undefined,updatefunction);
}

//提交新的appid
function newAppIdSubmit(data,updatefunction){
    send_request('/queryData/updateApp',data,updatefunction);
}

function columnSorter(a,b){
    if (a < b) {
        return -1;
    }
    if (b > a) {
        return 1;
    }
    return 0;
}









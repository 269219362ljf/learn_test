import React from 'react';
import {Card, Col, Row, Switch,Radio} from 'antd';
import {connect} from 'react-redux';
import {LOADSYSFORCEDATA, loadSysForceData} from "../actions";
import ForceChart from "../components/charts/ForceChart";
import axios from 'axios';
import {snowden_api_url} from "../constants";
import {transformNodesAndLines} from "../utils/commonUtils";

const RadioGroup = Radio.Group;

export function SystemForceDataReducer(state = {}, action) {
    switch (action.type) {
        case LOADSYSFORCEDATA:
            return Object.assign({}, state, {data: transformData(action.data)});
        default:
            return state;
    }
}

//将action的数据进行转化
function transformData(data) {
    return transformNodesAndLines(data);
}

const mapStateToProps = (state) => {
    return {sysForceData: state.sysForceData.data};
};

const mapDispatchToProps = (dispatch) => {
    return {
        loadSysForceData: (data) => dispatch(loadSysForceData(data))
    }
};

class SystemForceChartContainer extends React.Component {
    state = {
        value: 1,
    };
    render() {
        return (
            <div className={"gutter-example simple-force-chart-demo container"}>
                <Row gutter={24}>
                    <Col className={"gutter-row"} md={24}>
                        <div className={"gutter-box"}>
                            <Card title={"风控系统拓扑图"} bordered={false} style={{ width: 1500 }}>
                                <Row>
                                    <Col span={2}>
                                        <Switch checkedChildren="wg1" unCheckedChildren="wg1" defaultChecked
                                                onChange={this.onEzoneChange}/>
                                    </Col>
                                    <Col span={2}>
                                        <Switch checkedChildren="xg1" unCheckedChildren="xg1" defaultChecked
                                                onChange={this.onEzoneChange}/>
                                    </Col>
                                    <Col span={2}>
                                        <Switch checkedChildren="zb1" unCheckedChildren="zb1" defaultChecked
                                                onChange={this.onEzoneChange}/>
                                    </Col>
                                    <Col span={2}>
                                        <Switch checkedChildren="dal" unCheckedChildren="dal" defaultChecked
                                                onChange={this.onEzoneChange}/>
                                    </Col>
                                    <Col span={2}>
                                        <Switch checkedChildren="redis" unCheckedChildren="redis" defaultChecked
                                                onChange={this.onEzoneChange}/>
                                    </Col>
                                    <Col span={10}>
                                        <RadioGroup onChange={this.onChange} value={this.state.value}>
                                            <Radio value={1}>Last 10min</Radio>
                                            <Radio value={2}>Last 20min</Radio>
                                            <Radio value={3}>Last 30min</Radio>
                                            <Radio value={4}>Last 1h</Radio>
                                        </RadioGroup>
                                    </Col>
                                </Row>
                                <Row>
                                    <ForceChart data={this.props.sysForceData}/>
                                </Row>
                            </Card>
                        </div>
                    </Col>
                </Row>
            </div>
        )
    }

    componentDidMount() {
        axios.get(snowden_api_url + '/queryData/queryFramworkData', {
            headers: {
                'Accept': 'application/json',
                'content-type': 'application/json'
            }
        }).then((response) => {
            this.props.loadSysForceData(response.data);
        }).catch((error) => {
            console.error("error", error);
        });
    }

    componentDidUpdate() {

    }

    onEzoneChange(status) {
        console.log("onEzoneChange", status);
    }

    onChange = (e) => {
        this.setState({
            value: e.target.value,
        });
    }

}

export default connect(mapStateToProps, mapDispatchToProps)(SystemForceChartContainer);







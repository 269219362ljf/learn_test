import React from 'react';
import {Card,Button, Col, Form, Input, Row,Table} from 'antd';
import axios from 'axios';
import {snowden_api_url} from '../constants';
const FormItem = Form.Item;

//获取QPS数据
function searchQpsData(query,updatefunction){
    console.log("searchQpsData query",query);
    try{
        console.log("url",snowden_api_url+'/queryData/qpsData');
        axios.get(snowden_api_url+'/queryData/qpsData',{
            headers: {
                'Accept': 'application/json',
                'content-type':'application/json'
            },
            params:query
        }).then((response)=>{
            updatefunction(response.data.data);
        }).catch((error)=>{
            console.error("error",error);
        });
    }catch (err) {
        console.error(err);
    }
}

//查询表单
class QpsFormClass extends React.Component{

    render(){
        const  {getFieldDecorator} = this.props.form;
        return (
            <Form className="ant-advanced-search-form"
                  onSubmit={this.qpsDataSearch}
                  layout="inline"
            >
                <Row>
                    <Col span={8}  >
                        <FormItem label={`AppId`} >
                            {getFieldDecorator('appid', {
                                rules: [{
                                    required: false
                                }],
                            })(
                                <Input placeholder="查询appid,如dt.xavier"  />
                            )}
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span={24} style={{textAlign:"right"}}>
                        <Button type="primary" htmlType="submit">查询</Button>
                        <Button style={{ marginLeft: 8 }} onClick={this.formReset}>
                            清空
                        </Button>
                    </Col>
                </Row>
            </Form>
        );
    }

    //提交function
    qpsDataSearch = (e) => {
        e.preventDefault();
        this.props.form.validateFields((err, values) => {
            searchQpsData(values,this.props.parent.updateData);
        });
    };

    //重置function
    formReset = () => {
        this.props.form.resetFields();
    };


}
const QpsForm = Form.create()(QpsFormClass);

//数据表
class QpsDataTable extends React.Component{

    columnSorter=(a,b)=>{
        if (a < b) {
            return -1;
        }
        if (b > a) {
            return 1;
        }
        return 0;
    };

    columns=[{
        title:'appId',
        dataIndex:'appId',
        align:'center',
        defaultSortOrder:'descend',
        sorter: (a,b)=>this.columnSorter(a.appId,b.appId),
    },{
        title:'counter',
        dataIndex:'counter',
        align:'center',
        defaultSortOrder:'descend',
        sorter: (a,b)=>this.columnSorter(a.counter,b.counter),
    },{
        title:'counterTimestamp',
        dataIndex:'counterTimestamp',
        align:'center',
        defaultSortOrder:'descend',
        sorter: (a,b)=>this.columnSorter(a.counterTimestamp,b.counterTimestamp),
    }];

    render(){
        return(
          <Table columns={this.columns} dataSource={this.props.data} />
        );
    }
}

//整个页面
class QpsChartContainer extends React.Component{

    componentDidMount() {
        this.qpsdata=searchQpsData(null,this.updateData);
        //由于修改的不是state，所以默认不会重新渲染，需要强制重新渲染
        this.forceUpdate();
    }

    updateData=(data)=>{
        this.qpsdata=data;
        this.forceUpdate();
    };

    render(){
        return (
            <div className={"gutter-example simple-force-chart-demo"}>
                <Row gutter={10}>
                    <Col className={"gutter-row"} md={24}>
                        <div className={"gutter-box"}>
                            <Card title={"风控系统qps"} bordered={false}>
                                <QpsForm parent={this}/>
                                <QpsDataTable data={this.qpsdata} />
                            </Card>
                        </div>
                    </Col>
                </Row>
            </div>
        );
    }
}

export default QpsChartContainer;













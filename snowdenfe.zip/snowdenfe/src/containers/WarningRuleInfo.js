import React from 'react';
import {Card, Button, Col, Form, Input, Row, Select,} from 'antd';
import axios from 'axios';
import {snowden_api_url} from '../constants';
import {urlpost} from "../utils/connectSupport";

const FormItem = Form.Item;
const Option = Select.Option;

class WarningRuleSubmitFormClass extends React.Component {

    state = {
        rule_type: 'unkown',
    };

    render() {
        const {getFieldDecorator} = this.props.form;
        const pointVisible = this.state.rule_type === '1' ? {display: "inline"} : {display: "none"};
        const linkVisible = this.state.rule_type === '2' ? {display: "inline"} : {display: "none"};
        return (
            <Form className="ant-advanced-search-form"
                  onSubmit={this.sendWarningRule}
                  layout="inline"
            >
                <Row>
                    <Col span={24}>
                        <FormItem label={`告警规则id`}>
                            {getFieldDecorator('warningRuleName', {
                                rules: [{
                                    required: true
                                }],
                            })(
                                <Input/>
                            )}
                        </FormItem>
                        <FormItem label={`触发点`}>
                            {getFieldDecorator('pointType',{
                                rules: [{
                                    required: true
                                }],
                            })(
                                <Select  style={{width: 70}} onChange={this.point_type_Select_onChange}>
                                    <Option value="1" >点</Option>
                                    <Option value="2">线</Option>
                                </Select>
                            )}
                        </FormItem>
                        <div style={pointVisible}>
                            <FormItem label={`节点id`}>
                                {getFieldDecorator('pointId', {
                                    rules: [{
                                        required: true
                                    }],
                                })(
                                    <Input/>
                                )}
                            </FormItem>
                        </div>
                        <div style={linkVisible}>
                            <FormItem label={`消费方`}>
                                {getFieldDecorator('consumer', {
                                    rules: [{
                                        required: true
                                    }],
                                })(
                                    <Input/>
                                )}
                            </FormItem>
                            <FormItem label={`提供方`}>
                                {getFieldDecorator('provider', {
                                    rules: [{
                                        required: true
                                    }],
                                })(
                                    <Input/>
                                )}
                            </FormItem>
                        </div>
                    </Col>
                </Row>
                <Row>
                    <FormItem label={`平均调用时间`}>
                        {getFieldDecorator('op', {
                            rules: [{
                                required: true
                            }],
                        })(
                            <Select  style={{width: 70}}>
                                <Option value=">" >&gt;</Option>
                                <Option value="=">=</Option>
                                <Option value="<">&lt;</Option>
                            </Select>
                        )}
                        {getFieldDecorator('threshold', {
                            rules: [{
                                required: false
                            }],
                        })(
                            <Input style={{width: 70}}/>
                        )}
                        <text>ms</text>
                    </FormItem>
                    <FormItem label={`通知用户id`}>
                        {getFieldDecorator('userId', {
                            rules: [{
                                required: true
                            }],
                        })(
                            <Input/>
                        )}
                    </FormItem>
                    <FormItem label={`规则状态`}>
                        {getFieldDecorator('indicatorActive', {
                            rules: [{
                                required: true
                            }],
                        })(
                            <Select  style={{width: 100}}>
                                <Option value="0" >未激活</Option>
                                <Option value="1">激活</Option>
                            </Select>
                        )}
                    </FormItem>

                </Row>
                <Row>
                    <Col span={24} style={{textAlign: "right"}}>
                        <Button type="primary" htmlType="submit">提交</Button>
                        <Button style={{marginLeft: 8}} onClick={this.formReset}>
                            清空
                        </Button>
                    </Col>
                </Row>
            </Form>
        );
    }

    //必须要使用()=>形式，否则由于js作用域范围，导致this.setState出问题
    point_type_Select_onChange=(value)=>{
        this.setState({
            rule_type: value,
        });
    };

    sendWarningRule= (e) => {
        e.preventDefault();
        this.props.form.validateFields((err, values) => {
            console.log("submit values",values);
            urlpost(snowden_api_url + '/Warning/warningRuleAdd', values,
                (response) => {
                    alert("success");
                },
                (error) => {
                    console.error("error", error);
                    alert("error");
                }
            );
        });
    }
}

const WarningRuleSubmitForm = Form.create()(WarningRuleSubmitFormClass);

class WarningRuleQueryFormClass extends React.Component{
    render(){
        const {getFieldDecorator} = this.props.form;
        return(
            <Form className="ant-advanced-search-form"
                  onSubmit={this.sendWarningRule}
                  layout="inline"
            >
                <Row>
                    <Col span={24}>
                        <FormItem label={`告警规则名`}>
                            {getFieldDecorator('warningRuleName', {
                                rules: [{
                                    required: false
                                }],
                            })(
                                <Input/>
                            )}
                        </FormItem>
                    </Col>
                </Row>



            </Form>
        )
    }

    queryWarningRule=(e) => {

    }
}

const WarningRuleQueryForm = Form.create()(WarningRuleQueryFormClass);




class WarningRuleInfo extends React.Component {


    render() {
        return (
            <div>
                <Card title={"规则新增/更新"} bordered={false}>
                    <WarningRuleSubmitForm/>

                </Card>
            </div>
        )
    }


}

export default WarningRuleInfo;

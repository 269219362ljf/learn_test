import React from 'react';
import {Card, Button, Col, Form, Input, Row, Table} from 'antd';
import axios from 'axios';
import {snowden_api_url} from '../constants';
import {urlGet, urlpost} from '../utils/connectSupport';

const FormItem = Form.Item;

//新增/更新系统变量表单
class SysUpdateFormClass extends React.Component {

    render() {
        const {getFieldDecorator} = this.props.form;
        return (
            <Form className="ant-advanced-search-form"
                  onSubmit={this.systemSettingSubmit}
                  layout="inline"
            >
                <Row>
                    <Col span={8}>
                        <FormItem label={`系统变量名`}>
                            {getFieldDecorator('settingName', {
                                rules: [{
                                    required: false
                                }],
                            })(
                                <Input placeholder="settingName"/>
                            )}
                        </FormItem>
                    </Col>
                    <Col span={8}>
                        <FormItem label={`系统变量值`}>
                            {getFieldDecorator('settingValue', {
                                rules: [{
                                    required: false
                                }],
                            })(
                                <Input placeholder="settingValue"/>
                            )}
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span={24} style={{textAlign: "right"}}>
                        <Button type="primary" htmlType="submit">设置</Button>
                        <Button style={{marginLeft: 8}} onClick={this.formReset}>
                            清空
                        </Button>
                    </Col>
                </Row>
            </Form>
        );
    }

    //提交function
    systemSettingSubmit = (e) => {
        e.preventDefault();
        this.props.form.validateFields((err, values) => {
            console.log(values);
            urlpost(snowden_api_url + '/SystemSetting/updateSetting', values,
                (response) => {
                    alert("success");
                },
                (error) => {
                    console.error("error", error);
                    alert("error");
                }
            );
        });
    };

    //重置function
    formReset = () => {
        this.props.form.resetFields();
    };
}

const SysUpdateForm = Form.create()(SysUpdateFormClass);

//查询系统变量表单
class SysQueryFormClass extends React.Component {

    render() {
        const {getFieldDecorator} = this.props.form;
        return (
            <Form className="ant-advanced-search-form"
                  onSubmit={this.systemSettingQuery}
                  layout="inline"
            >
                <Row>
                    <Col span={8}>
                        <FormItem label={`系统变量名`}>
                            {getFieldDecorator('settingName', {
                                rules: [{
                                    required: false
                                }],
                            })(
                                <Input placeholder="settingName"/>
                            )}
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span={24} style={{textAlign: "right"}}>
                        <Button type="primary" htmlType="submit">查询</Button>
                        <Button style={{marginLeft: 8}} onClick={this.formReset}>
                            清空
                        </Button>
                    </Col>
                </Row>
            </Form>
        );
    }

    //提交function
    systemSettingQuery = (e) => {
        e.preventDefault();
        this.props.form.validateFields((err, values) => {
            urlGet(snowden_api_url + '/SystemSetting/querySystemSetting', values,
                (response) => {
                this.props.parent.updateTableData(response.data.data);
                },
                (error) => {
                    console.error("error", error);
                    alert("error");
                });
        });
    };
    //重置function
    formReset = () => {
        this.props.form.resetFields();
    };
}

const SysQueryForm = Form.create()(SysQueryFormClass);

//数据表
class SystemSettingTable extends React.Component {

    columns = [{
        title: '系统变量名',
        dataIndex: 'settingName',
        align: 'center',
        key: 'settingName',
        width:60
    }, {
        title: '系统变量值',
        dataIndex: 'settingValue',
        align: 'center',
        key: 'settingValue',
        width:120
    }];

    render() {
        return (
            <Table columns={this.columns} dataSource={this.props.data}/>
        );
    }
}


//整个页面
class SystemSetting extends React.Component {

    render() {
        return (
            <div className={"gutter-example simple-force-chart-demo"}>
                <Row gutter={10}>
                    <Col className={"gutter-row"} md={24}>
                        <div className={"gutter-box"}>
                            <Card title={"系统变量设置"} bordered={false}>
                                <Card title={"系统新增/更新"} bordered={false}>
                                    <SysUpdateForm parent={this}/>
                                </Card>
                                <Card title={"系统变量查询"} bordered={false}>
                                    <SysQueryForm parent={this}/>
                                    <SystemSettingTable data={this.sysdata}/>
                                </Card>
                            </Card>
                        </div>
                    </Col>
                </Row>
            </div>
        );
    }

    updateTableData(data){
        this.sysdata=data;
        this.forceUpdate();
    }
}

export default SystemSetting;






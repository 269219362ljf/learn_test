import React from 'react';
import {Card,Button, Col, Form, Input, Row} from 'antd';
import axios from 'axios';
import {snowden_api_url} from '../constants';
const FormItem = Form.Item;

//查询表单
class WarningFormClass extends React.Component{
    render(){
        const  {getFieldDecorator} = this.props.form;
        return (
            <Form className="ant-advanced-search-form"
                  onSubmit={this.sendWarning}
                  layout="inline"
            >
                <Row>
                    <Col span={8}  >
                        <FormItem label={`告警内容`} >
                            {getFieldDecorator('warning_content', {
                                rules: [{
                                    required: false
                                }],
                            })(
                                <Input   />
                            )}
                        </FormItem>
                        <FormItem label={`告警对象`} >
                            {getFieldDecorator('target_phone', {
                                rules: [{
                                    required: false
                                }],
                            })(
                                <Input placeholder="告警对象手机号码"  />
                            )}
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span={24} style={{textAlign:"right"}}>
                        <Button type="primary" htmlType="submit">提交</Button>
                        <Button style={{ marginLeft: 8 }} onClick={this.formReset}>
                            清空
                        </Button>
                    </Col>
                </Row>
            </Form>
        );
    }
    sendWarning=(e)=>{
        this.props.form.validateFields((err, values) => {
            send_warning(values);
        });
    };
    //重置function
    formReset = () => {
        this.props.form.resetFields();
    };
}

const WarningForm = Form.create()(WarningFormClass);

//整个页面
class WarningContainer extends React.Component{
    render(){
        console.log("baseUrl",snowden_api_url);
        return (
            <div className={"gutter-example simple-force-chart-demo"}>
                <Row gutter={10}>
                    <Col className={"gutter-row"} md={24}>
                        <div className={"gutter-box"}>
                            <Card title={"风控系统监控手动告警"} bordered={false}>
                                <WarningForm/>
                            </Card>
                        </div>
                    </Col>
                </Row>
            </div>
        );
    }
}

export default WarningContainer;

function send_warning(params) {
    try {
        axios.post(snowden_api_url+'/Warning/handWarning',params)
            .then((response)=>{
                alert("success");
            }).catch((error)=>{
            console.error("error",error);
            alert("error");
        });
    } catch (err) {
        console.error(err);
    }
}








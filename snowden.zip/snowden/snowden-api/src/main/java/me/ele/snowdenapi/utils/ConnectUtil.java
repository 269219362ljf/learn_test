package me.ele.snowdenapi.utils;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class ConnectUtil {

    public HttpURLConnection createBaseHttpURLConnection(String address) throws Exception {
        URL url = new URL(address);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestProperty("accept", "application/json");
        connection.setRequestProperty("content-type", "application/json;");
        connection.setRequestProperty("connection", "Keep-Alive");
        connection.setInstanceFollowRedirects(false);
        connection.setConnectTimeout(30000);
        return connection;
    }

    public StringBuffer sendRequestWithPayLoad(HttpURLConnection connection,String payLoad) throws Exception {
        connection.setDoInput(true);
        connection.setDoOutput(true);
        OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
        writer.write(payLoad);
        writer.close();
        BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        String line = null;
        StringBuffer sb = new StringBuffer();
        while ((line = br.readLine()) != null) {
            sb.append(line);
        }
        if(br!=null){
            br.close();
            br=null;
        }
        return sb;
    }










}

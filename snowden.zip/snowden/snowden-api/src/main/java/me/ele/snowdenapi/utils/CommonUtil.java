package me.ele.snowdenapi.utils;

import com.alibaba.fastjson.JSON;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class CommonUtil {

   /**
     * 通过PrintWriter将响应数据写入response，ajax可以接受到这个数据
     *
     * @param response
     * @param data
     */
    public static void renderData(HttpServletResponse response, Object data) {
        PrintWriter printWriter = null;
        try {
            printWriter = response.getWriter();
            printWriter.print(JSON.toJSONString(data));
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            if (null != printWriter) {
                printWriter.flush();
                printWriter.close();
            }
            //设置返回数据类型
            response.setContentType("application/json");
            //解决跨域问题，接受所有域的访问
            response.addHeader("Access-Control-Allow-Origin", "*");
        }
    }

}

package me.ele.snowdenapi.model;


import lombok.Data;

import java.io.Serializable;

@Data
public class TestModel implements Serializable {

    private String id;
    private String data;

}

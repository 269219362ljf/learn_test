package me.ele.snowdenapi.service;

import com.alibaba.fastjson.JSONObject;
import me.ele.snowdenapi.model.MetricBean;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class MonitorDataService {

    public JSONObject createPayload(String api,String from,String to){
        MetricBean result=new MetricBean();
        result.setEntity("application");
        result.setPrefix(api);
        result.setMeasurement("soa_provider");
        ArrayList<String> fields=new ArrayList<>();
        fields.add("timerCount");
        result.setFields(fields);
        result.setTagFilters(new ArrayList<>());
        //result.setFrom("now()-1h");
        //result.setFrom("2018-10-15 00:00:00");
        result.setFrom(from);
        //result.setTo("now()-30s");
        //result.setTo("2018-10-15 23:59:59");
        result.setTo(to);
        result.setOrderBy("timerCount DESC limit 10");
        return JSONObject.parseObject(JSONObject.toJSONString(result));
    }



}

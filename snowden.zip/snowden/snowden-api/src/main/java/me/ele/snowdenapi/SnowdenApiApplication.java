package me.ele.snowdenapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SnowdenApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(SnowdenApiApplication.class, args);
    }
}

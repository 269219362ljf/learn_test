package me.ele.snowdenapi.constants;

public class Constants {

    public static String monitorUrl="https://etrace-gw.ele.me/monitor/metric";







}

package me.ele.snowdenapi.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

/**
 * @author dupeng
 *         Date:2018/3/19
 *         Time:下午4:46
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class TagFilter {

    private String key;
    private String op;
    private List<String> value;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getOp() {
        return op;
    }

    public void setOp(String op) {
        this.op = op;
    }

    public List<String> getValue() {
        return value;
    }

    public void setValue(List<String> value) {
        this.value = value;
    }
}

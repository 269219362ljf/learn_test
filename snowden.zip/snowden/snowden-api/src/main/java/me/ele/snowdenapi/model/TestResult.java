package me.ele.snowdenapi.model;

import lombok.Data;

@Data
public class TestResult {

    private Object data;



}

package me.ele.snowdentimer.task;

import me.ele.snowdentimer.constants.Constants;
import me.ele.snowdentimer.model.QpsData;
import me.ele.snowdentimer.service.CrawlerService;
import me.ele.snowdentimer.utils.RedisUtil;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service
public class CrawlerTask extends QuartzJobBean {

    private static Logger log = LoggerFactory.getLogger(CrawlerTask.class);

    @Autowired
    private CrawlerService crawlerService;

    @Autowired
    private RedisUtil redisUtil;

    @Override
    protected void executeInternal(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        List<QpsData> qpsDataList=crawlerService.getQpsData(null,null,null, Constants.appids);
        System.out.println("Crawler Data begin");
        qpsDataList.parallelStream().forEach((item)->{
            try{
                Long timepoint=item.getStartTime();
                Long interval=item.getInterval();
                Long[] timecount=item.getTimerCount();
                for(int i=0;i<timecount.length;i++){
                    String key=item.getAppid()+"_qps_"+timepoint;
                    redisUtil.hset(item.getAppid(),key,timecount[i]);
                    timepoint+=interval;
                }
            }catch (Exception e){
                log.error(" CrawlerTask error appid:{} error:{}",item.getAppid(),e);
            }
        });
        System.out.println("Crawler Data end");

    }
}

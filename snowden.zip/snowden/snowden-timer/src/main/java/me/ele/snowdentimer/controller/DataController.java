package me.ele.snowdentimer.controller;


import me.ele.snowdentimer.utils.RedisUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/query")
@Repository
public class DataController {



    @Autowired
    RedisUtil redisUtil;

    @RequestMapping(value = "/redisTest",method = RequestMethod.GET)
    public Object redisTest(){
        redisUtil.hset("redisTest","redisTestKey",1L);
        if(redisUtil.hasKey("redisTest")){
            return redisUtil.hget("redisTest","redisTestKey");
        }
        return null;
    }










}

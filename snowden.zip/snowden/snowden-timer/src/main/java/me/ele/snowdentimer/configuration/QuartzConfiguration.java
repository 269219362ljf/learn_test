package me.ele.snowdentimer.configuration;



import me.ele.snowdentimer.task.CrawlerTask;
import org.quartz.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;


@Configuration
@EnableAsync
public class QuartzConfiguration {

    @Value("${crawler_task_seconds}")
    private int crawlerSeconds;


    @Bean
    public JobDetail CrawlerTaskQuartzDetail(){
        return JobBuilder.newJob(CrawlerTask.class).withIdentity("CrawlerTask").storeDurably().build();
    }

    @Bean
    public Trigger CrawlerTaskQuartzTrigger(){
        SimpleScheduleBuilder scheduleBuilder = SimpleScheduleBuilder.simpleSchedule()
                .withIntervalInSeconds(crawlerSeconds)  //设置时间周期单位秒
                .repeatForever();
        return TriggerBuilder.newTrigger().forJob(CrawlerTaskQuartzDetail())
                .withIdentity("CrawlerTaskQuartz")
                .withSchedule(scheduleBuilder)
                .build();
    }

}

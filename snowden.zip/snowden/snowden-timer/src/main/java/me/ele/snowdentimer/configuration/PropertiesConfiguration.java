package me.ele.snowdentimer.configuration;


import org.springframework.context.annotation.Configuration;

@Configuration
//@PropertySource("classpath:config.properties")
public class PropertiesConfiguration {
}

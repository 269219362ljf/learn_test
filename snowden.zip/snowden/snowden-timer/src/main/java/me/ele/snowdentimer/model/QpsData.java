package me.ele.snowdentimer.model;

import lombok.Data;

@Data
public class QpsData {

    private String appid;
    private Long startTime;
    private Long interval;
    private Long endTime;
    private Long pointCount;
    private Long[] timerCount;
}

package me.ele.snowdentimer.utils;

import com.alibaba.fastjson.JSONArray;
import me.ele.snowdentimer.constants.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;


public class CrawlerUtils {

    private static Logger log = LoggerFactory.getLogger(CrawlerUtils.class);

    public JSONArray fetchData(String url,JSONArray payloads,String method){
        try{
            URL realUrl = new URL(url);
            HttpURLConnection connection = (HttpURLConnection) realUrl.openConnection();
            connection.setDoInput(true);
            connection.setDoOutput(true);
            connection.setRequestProperty("accept", "application/json");
            connection.setRequestProperty("content-type", "application/json;");
            connection.setRequestMethod("PUT");
            connection.setInstanceFollowRedirects(false);
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setConnectTimeout(30000);
            connection.setRequestProperty("Cookie", Constants.MONITOR_API_COOKIE);
            OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
            writer.write(payloads.toJSONString());
            writer.close();
            BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line = null;
            StringBuffer sb = new StringBuffer();
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            if(br!=null){
                br.close();
                br=null;
            }
            connection.disconnect();
            return JSONArray.parseArray(sb.toString());
        }catch (Exception e){
            log.error("CrawlerUtils fetchData error {}",e);
            return null;
        }
    }
}

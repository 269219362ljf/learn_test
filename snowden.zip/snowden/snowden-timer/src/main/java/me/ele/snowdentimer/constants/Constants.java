package me.ele.snowdentimer.constants;

import java.util.concurrent.TimeUnit;

public class Constants {

    public static String METRIC_URL="https://etrace-gw.ele.me/monitor/metric";

    public static String MONITOR_API_COOKIE="MONITOR_API_TOKEN=94A727D217DEEA0DB30B63C23E2D99B5F56C66B0E35714574CCD19271121F972; Max-Age=7464960000; Expires=Wed, 16-May-2255 09:19:09 GMT; Path=/";
    //public static String MONITOR_API_COOKIE="MONITOR_API_TOKEN=7D166333E28456ED68F06A2D51835ABEDD08DA86B00A30D5AF29BE392CAA95D8";

    public static Long REDIS_EXPIRETIME=3600L;

    public static TimeUnit REDIS_EXPIRETIME_TIMEUNIT=TimeUnit.SECONDS;

    public static String[] appids={"dt.xavier","risk.newton.api","risk.davinci.engine","risk.executor"};






}

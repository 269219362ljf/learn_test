package me.ele.snowdentimer.service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import me.ele.snowdentimer.constants.Constants;
import me.ele.snowdentimer.model.MetricBean;
import me.ele.snowdentimer.model.QpsData;
import me.ele.snowdentimer.utils.CrawlerUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
public class CrawlerService {

    private static Logger log = LoggerFactory.getLogger(CrawlerService.class);


    private CrawlerUtils crawlerUtils=new CrawlerUtils();


    public List<QpsData> getQpsData(String from, String to, String orderby, String ...appids){
        JSONArray payloads=new JSONArray();
        List<QpsData> result=new ArrayList<>();
        List<String> appidList=Arrays.asList(appids);
        if(appids!=null) {
            for(int i=0;i<appidList.size();i++){
                payloads.add(createPayload(appidList.get(i), from, to, orderby));
            }
        }
        if(payloads.size()==0){
            return result;
        }
        JSONArray qpsDatas=crawlerUtils.fetchData(Constants.METRIC_URL,payloads,"PUT");
        if(qpsDatas==null||qpsDatas.size()==0){
            log.info("getQpsData get nothing please check query :{}",payloads.toJSONString());
            return result;
        }
        try {
            for(int i=0;i<qpsDatas.size();i++){
                result.add(buildQpsData(qpsDatas.getJSONObject(i)));
            }
            return result;
        }catch (Exception e){
            log.error("getQpsData analyze error:{}",e);
            return new ArrayList<>();
        }

    }

    public QpsData buildQpsData(JSONObject item){
        QpsData result=new QpsData();
        result.setAppid(item.getString("name"));
        JSONObject itemResults=item.getJSONObject("results");
        result.setStartTime(itemResults.getLongValue("startTime"));
        result.setInterval(itemResults.getLongValue("interval"));
        result.setEndTime(itemResults.getLongValue("endTime"));
        result.setPointCount(itemResults.getLongValue("pointCount"));
        JSONArray timerCount=itemResults.getJSONArray("groups")
                .getJSONObject(0).getJSONObject("fields")
                .getJSONArray("timerCount");
        Long[] result_timerCount=new Long[timerCount.size()];
        for(int i=0;i<timerCount.size();i++){
            result_timerCount[i]=timerCount.getLongValue(i);
        }
        result.setTimerCount(result_timerCount);
        return result;
    }




    public JSONObject createPayload(String prefix,String from,String to,String orderby){
        MetricBean result=new MetricBean();
        result.setEntity("application");
        result.setPrefix(prefix);
        result.setMeasurement("soa_provider");
        ArrayList<String> fields=new ArrayList<>();
        fields.add("timerCount");
        result.setFields(fields);
        result.setTagFilters(new ArrayList<>());
        if(from==null){
            result.setFrom("now()-1h");
        }else{
            result.setFrom(from);
        }
        //result.setFrom("2018-10-15 00:00:00");
        if(to==null){
            result.setTo("now()-30s");
        }else{
            result.setTo(to);
        }
        //result.setTo("2018-10-15 23:59:59");
        if(to==null){
            result.setOrderBy("timerCount DESC limit 10");
        }else{
            result.setOrderBy(orderby);
        }
        return JSONObject.parseObject(JSONObject.toJSONString(result));
    }









}

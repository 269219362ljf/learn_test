package me.ele.snowdentimer;

import me.ele.snowdentimer.model.QpsData;
import me.ele.snowdentimer.service.CrawlerService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SnowdenTimerApplicationTests {

//    @Test
//    public void contextLoads() {
//    }
//
//    @Test
//    public void testCrawler(){
//        CrawlerService crawlerService=new CrawlerService();
//        List<QpsData> qpsDataList=crawlerService.getQpsData(null,null,null,"dt.xavier");
//        if(qpsDataList==null||qpsDataList.size()==0){
//            System.out.println("fail");
//        }else{
//            QpsData qpsData=qpsDataList.get(0);
//            System.out.println(qpsData.getAppid());
//        }
//
//
//    }

}

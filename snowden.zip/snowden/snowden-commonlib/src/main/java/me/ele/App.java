package me.ele;

import me.ele.common.dingtalk.*;

import java.util.ArrayList;
import java.util.List;

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) {
        DingTalkMsg dingTalkMsg = new DingTalkMsg();
        dingTalkMsg.setMsgtype("text");
        DingTalkContent dingTalkContent = new DingTalkContent();
        dingTalkContent.setContent("xavier 报警测试! ");
        AtData atData = new AtData();
        List<String> atMobiles = new ArrayList<>();
        atMobiles.add("15975533427");
        atData.setAtMobiles(atMobiles);
        atData.setIsAtAll(true);
        dingTalkMsg.setText(dingTalkContent);
        dingTalkMsg.setAt(atData);
        DingTalkResponse response = DingTalkHelper.sendDingTalkContext("xavier 报警测试!", atMobiles, false, "8271a324b5110a30c54cbf2cae8e790dd45d78e773df892891936202f2d30090");
        System.out.println(response.getErrMsg());
    }
}

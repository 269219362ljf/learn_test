package me.ele.common.dingtalk;

/**
 * Created by yuanjialin on 2018/10/26.
 */
public class DingTalkMsg {
    private String msgtype;
    private DingTalkContent text;
    private AtData at;

    public String getMsgtype() {
        return msgtype;
    }

    public void setMsgtype(String msgtype) {
        this.msgtype = msgtype;
    }

    public DingTalkContent getText() {
        return text;
    }

    public void setText(DingTalkContent text) {
        this.text = text;
    }

    public AtData getAt() {
        return at;
    }

    public void setAt(AtData at) {
        this.at = at;
    }


}

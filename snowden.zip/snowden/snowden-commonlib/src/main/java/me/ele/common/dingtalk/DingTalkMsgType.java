package me.ele.common.dingtalk;

/**
 * Created by yuanjialin on 2018/10/26.
 */
public enum DingTalkMsgType {
    Text("text", 1),
    Link("link", 2);

    private String dingTalkMsgTypeName;
    private int id;

    DingTalkMsgType(String dingTalkMsgTypeName, int id) {
        this.dingTalkMsgTypeName = dingTalkMsgTypeName;
        this.id = id;
    }

    public String getDingTalkMsgTypeName() {
        return dingTalkMsgTypeName;
    }

    public int getId() {
        return id;
    }

    public DingTalkMsgType getDingTalkMsgTypeName(int id) {
        switch (id) {
            case 1:
                return DingTalkMsgType.Text;
            case 2:
                return DingTalkMsgType.Link;
            default:
                return DingTalkMsgType.Text;
        }
    }

}

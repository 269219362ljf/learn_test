package me.ele.common.utils;

import org.slf4j.Logger;
import org.springframework.web.cors.CorsConfiguration;

import java.util.Set;
import java.util.concurrent.TimeUnit;

public class CommonUtils {

    public static TimeUnit getRedisExpiretimeTimeunit(String REDIS_EXPIRETIME_TIMEUNIT_STR) {
        switch (REDIS_EXPIRETIME_TIMEUNIT_STR) {
            case "TimeUnit.NANOSECONDS":
                return TimeUnit.NANOSECONDS;
            case "TimeUnit.MICROSECONDS":
                return TimeUnit.MICROSECONDS;
            case "TimeUnit.MILLISECONDS":
                return TimeUnit.MILLISECONDS;
            case "TimeUnit.SECONDS":
                return TimeUnit.SECONDS;
            case "TimeUnit.MINUTES":
                return TimeUnit.MINUTES;
            case "TimeUnit.HOURS":
                return TimeUnit.HOURS;
            case "TimeUnit.DAYS":
                return TimeUnit.DAYS;
            default:
                return TimeUnit.SECONDS;
        }
    }

    //跨域访问全局配置
    public static CorsConfiguration buildConfig() {
        CorsConfiguration corsConfiguration = new CorsConfiguration();
        corsConfiguration.addAllowedOrigin("*");
        corsConfiguration.addAllowedHeader("*");
        corsConfiguration.addAllowedMethod("*");
        return corsConfiguration;
    }

    public static String buildRedisKey(String method, String consumer, String provider,
                                       String ezone, String postfix_counter) {
        return method + "_" + consumer
                + "_" + provider + "_" + ezone + "_" + postfix_counter;
    }

    /**
     * 聚合数据
     *
     * @param values
     * @param log
     * @return
     */
    public static Long getCounterAndSumValue(Set<Object> values, Logger log) {
        Long result = 0L;
        for (Object item : values) {
            String[] v_array = ((String) item).split("_");
            if (v_array.length < 2) {
                log.error(" value not match format XX_XX " + item);
                continue;
            }
            String value = v_array[1];
            Long tempValue = 0L;
            try {
                tempValue = Long.valueOf(value);
                result += tempValue;
            } catch (Exception e) {
                log.error("value is not long format", value);
            }
        }
        return result;
    }


}

package me.ele.common.dingtalk;

/**
 * Created by yuanjialin on 2018/10/26.
 */
public class DingTalkResponse {
    private String errMsg = "";
    private int errcode = 0;

    public int getErrcode() {
        return errcode;
    }

    public void setErrcode(int errcode) {
        this.errcode = errcode;
    }

    public String getErrMsg() {
        return errMsg;
    }

    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg;
    }
}

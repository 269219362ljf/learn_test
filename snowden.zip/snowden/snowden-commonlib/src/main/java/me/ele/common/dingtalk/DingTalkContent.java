package me.ele.common.dingtalk;

/**
 * Created by yuanjialin on 2018/10/26.
 */
public class DingTalkContent {
    private String content;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}

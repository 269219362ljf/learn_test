package me.ele.common.dingtalk;

import java.util.List;

/**
 * Created by yuanjialin on 2018/10/26.
 */
public class AtData {
    private List<String> atMobiles = null;
    private boolean isAtAll = false;

    public List<String> getAtMobiles() {
        return atMobiles;
    }

    public void setAtMobiles(List<String> atMobiles) {
        this.atMobiles = atMobiles;
    }

    public boolean getIsAtAll() {
        return isAtAll;
    }

    public void setIsAtAll(boolean isAtAll) {
        this.isAtAll = isAtAll;
    }

}

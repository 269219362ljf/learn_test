package me.ele.common.dingtalk;


import com.alibaba.fastjson.JSON;
import me.ele.common.http.HttpClientUtil;

import java.util.List;

/**
 * Created by yuanjialin on 2018/10/26.
 */
public class DingTalkHelper {
    private final static String dingTalkUrl = "https://oapi.dingtalk.com/robot/send?access_token=";

    private static String sendDingTalk(DingTalkMsg dingTalkMsg, String token) {
        String payload = JSON.toJSONString(dingTalkMsg);
        String response = HttpClientUtil.sendPostRequest(dingTalkUrl + token, payload);
        return response;
    }

    public static DingTalkResponse sendDingTalkContext(String content, List<String> atMobiles, boolean isAtAll, String token) {
        DingTalkMsg dingTalkMsg = new DingTalkMsg();
        dingTalkMsg.setMsgtype(DingTalkMsgType.Text.getDingTalkMsgTypeName());
        DingTalkContent dingTalkContent = new DingTalkContent();
        dingTalkContent.setContent(content);
        AtData atData = new AtData();
        if (isAtAll) {
            atData.setIsAtAll(isAtAll);
            dingTalkMsg.setAt(atData);
        } else {
            if (atMobiles != null && atMobiles.size() > 0)
                atData.setAtMobiles(atMobiles);
            dingTalkMsg.setAt(atData);
        }
        dingTalkMsg.setText(dingTalkContent);
        String response = DingTalkHelper.sendDingTalk(dingTalkMsg, token);
        DingTalkResponse dingTalkResponse = JSON.parseObject(response, DingTalkResponse.class);
        if (dingTalkResponse != null) {
            return dingTalkResponse;
        } else {
            return null;
        }
    }
}

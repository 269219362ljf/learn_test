package me.ele;

import me.ele.common.dingtalk.DingTalkHelper;
import me.ele.common.dingtalk.DingTalkResponse;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertTrue;

/**
 * Unit test for simple App.
 */
public class AppTest {
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue() {
        assertTrue(true);
    }

    @Test
    public void testAtAll() {
        String content = "xavier 报警测试!";
        DingTalkResponse response = DingTalkHelper.sendDingTalkContext(content, null, true, "8271a324b5110a30c54cbf2cae8e790dd45d78e773df892891936202f2d30090");
        System.out.println(response.getErrMsg());
    }

    @Test
    public void testAtOne() {

        String content = "xavier 报警测试!";
        List<String> atMobiles = new ArrayList<>();
        atMobiles.add("18616554980");
        DingTalkResponse response = DingTalkHelper.sendDingTalkContext(content, atMobiles, false, "8271a324b5110a30c54cbf2cae8e790dd45d78e773df892891936202f2d30090");
        System.out.println(response.getErrMsg());
    }
}
